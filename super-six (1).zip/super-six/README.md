# SUPER SIX — private encrypted chat

Six fixed members (TANAY, PAVAN, MAYANK, AKSHIYAA, AYUSHI S, AARADHYA), each with a personal ID.
Group chat + private chats, files, voice messages, GIFs, stickers, 1:1 calls, and burnable guest links.

## Step 1 — Run it on your computer
1. Install Node.js 18 or newer (https://nodejs.org).
2. In this folder: `npm install` then `npm start`.
3. The terminal prints the **invite link** (it contains the room key). Open it.
4. Test with two browser windows (one private): log in as two different members.
   Try a private chat, a sticker, a file, **➕ Guest link** and **🔥 Burn room**.

Your personal IDs are in `members.json` (created on the first run). Keep that file private.

## Step 2 — Make it reachable with https (needed for calls, camera, microphone)

### Quick test (works while your computer is on)
1. Keep `npm start` running.
2. In another terminal: `npx ngrok http 3000` (free ngrok account needed) or
   `cloudflared tunnel --url http://localhost:3000` (no account).
3. Open the https address it prints. Your invite link is that address + `/#` + the roomKey from `members.json`.

### Permanent (Render.com, free tier)
1. Put this folder on GitHub as a **private** repository (`members.json` is already ignored by .gitignore).
2. On render.com: New → Web Service → connect the repo. Build `npm install`, start `npm start`.
3. Environment → add variable `MEMBERS_JSON` = the full text of your `members.json`.
4. Deploy. Render gives you an https address.
5. Invite link = `https://YOUR-APP.onrender.com/#` + roomKey (from `members.json`).
   Note: free instances sleep after inactivity, so the first open can take ~1 minute.

## Step 3 — Invite the others
- Send each person their own ID **privately**.
- Send everyone the invite link (it carries the room key).
- IDs on Render are changed by editing `MEMBERS_JSON`; the in-app **Change ID** only works when running from `members.json`.

## Step 4 — Test calls on two real devices
If a call will not connect (some mobile networks), add a TURN server in `members.json`:

    "iceServers": [
      {"urls": "stun:stun.l.google.com:19302"},
      {"urls": "turn:YOUR-TURN-HOST:3478", "username": "user", "credential": "pass"}
    ]

## Good to know
- Messages and files are encrypted in the browser; the server only relays them and stores nothing.
- Private-chat verify codes: if both people see the same code, nobody is in the middle.
- Guest links: anyone with the link can join until it burns. Anyone inside can burn it.
